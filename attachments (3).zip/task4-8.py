
def all_sort(x):
	if x.sort()==x:
		print("true")
	else:
		print("False")
all_sort(['d','c','e'])
