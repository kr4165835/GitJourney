def all_middle(x):
	a.pop[0]
	a.pop[-1]
	print(x)
all_middle([2,3,4,5,6])
